/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package utpasdd.sistemanotas;

/**
 *
 * @author garci
 */
public class SistemaNotas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
