
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaAlumnos extends javax.swing.JFrame {
    private JButton btnListar;

    public VentanaAlumnos() {
        initComponents();
    }

    private void initComponents() {
        btnListar = new JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnListar.setText("Listar Alumnos");
        btnListar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnListar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnListarActionPerformed(evt);
            }
        });

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(btnListar)
                .addContainerGap(200, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(btnListar)
                .addContainerGap(150, Short.MAX_VALUE))
        );

        pack();
    }

    private void btnListarActionPerformed(ActionEvent evt) {
        GestionAlumnos gestion = new GestionAlumnos();
        gestion.agregarAlumno(new Alumno(1, "Carlos", "Perez", "12345678"));
        gestion.agregarAlumno(new Alumno(2, "Ana", "Lopez", "87654321"));
        gestion.listarAlumnos();
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new VentanaAlumnos().setVisible(true);
        });
    }
}
